<?php
/* this is a comment
   and it seems to work ok...
*/
?>

