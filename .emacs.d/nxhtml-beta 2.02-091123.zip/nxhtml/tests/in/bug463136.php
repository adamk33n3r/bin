
<body>
  <?php
echo "test";
echo "test2";