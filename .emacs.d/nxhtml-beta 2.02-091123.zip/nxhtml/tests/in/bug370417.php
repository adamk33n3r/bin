<html>
  <body>
    <p>
      <?php
        echo "foo";
echo "bar";
      ?>
    </p>
  </body>
</html>
